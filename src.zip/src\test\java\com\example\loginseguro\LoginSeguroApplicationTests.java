package com.example.loginseguro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginSeguroApplicationTests {
    @Test
    void contextLoads() { }
}
