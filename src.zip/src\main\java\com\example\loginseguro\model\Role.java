package com.example.loginseguro.model;

public enum Role {
    USER, ADMIN
}
